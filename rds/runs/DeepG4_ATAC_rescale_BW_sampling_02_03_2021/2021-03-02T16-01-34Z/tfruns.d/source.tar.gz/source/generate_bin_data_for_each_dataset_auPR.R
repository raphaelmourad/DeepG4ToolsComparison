#Generate binned genome data (201) with BG4-G4seq K562 and control pos
require(tidyverse)
require(BSgenome.Hsapiens.UCSC.hg19)
require(plyranges)
library(scales)
binbed <- "/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/BED/random_region_for_scaling_min_max.bed" %>% read_bed()
#Functions
getSeq2 <- function(y,x){
  getSeq(x,y)
}
NormBW <- function(x,binbed){
  ranges_bin <- x %>% filter_by_overlaps(binbed) %>% .$score  %>% range(na.rm = TRUE, finite = TRUE)
  x$score <- rescale(x$score,to = c(0,1),from = ranges_bin)
  seqlengths(x) <- seqlengths(BSgenome.Hsapiens.UCSC.hg19)[seqlevels(x)]
  x <- coverage(x,weight = "score")
  return(x)
}
getScoreBW <- function (one.w, x) 
{
  require(magrittr)
  lapply(split(x, droplevels(seqnames(x))), function(zz) {
    message(unique(as.character(seqnames(zz))))
    cov <- one.w[[unique(as.character(seqnames(zz)))]]
    score <- IRanges::Views(cov, start = start(zz), end = end(zz)) %>% 
      as.matrix()
  }) %>% do.call("rbind",.)
}
DNAToNumerical <- function(x,tabv = c("N"=5,"T"=4,"G"=3,"C"=2,"A"=1),lower.case=F,seq.size = 201){
  if(lower.case){
    names(tabv) <- tolower(tabv)
  }
  x <- Biostrings::as.matrix(x)
  listMat <- list()
  for(i in 1:length(tabv)){
    nuc_index <- tabv[[i]]
    nuc_value <- names(tabv[i])
    mat <- matrix(0,nrow(x),ncol(x))
    mat[x==nuc_value] <- 1
    if(ncol(x)<seq.size){
      mat <- cbind(mat,matrix(0,nrow(x),seq.size-ncol(x)))
    }
    listMat[[nuc_index]] <- mat
  }
  arrayout <- array(unlist(listMat), dim = c(nrow(listMat[[1]]), ncol(listMat[[1]]), length(listMat)))
  return(arrayout)
  
}
mysize = 1000000
my.seed <- 74
seqlens <- seqlengths(BSgenome.Hsapiens.UCSC.hg19)
#GENERATE BIN 201 FROM ALL GENOME (DOWNSAMPLED TO 1M) RUN ONCE

bin_genome <- tileGenome(seqlens[1:23],tilewidth = 201,cut.last.tile.in.chrom = T)
bin_genome <- bin_genome %>% filter(width == 201)


G4pos.seq <- getSeq(BSgenome.Hsapiens.UCSC.hg19,bin_genome) 
resFreq <- Biostrings::letterFrequency(G4pos.seq,"N",as.prob = T)
testNFreq <- as.vector(resFreq>0.1)


bin_genome <- bin_genome[!testNFreq]
G4pos.seq <- G4pos.seq[!testNFreq]

bin_genome %>% write_bed(str_c("data/bin_genome.bed",sep="_"))


set.seed(my.seed)
my.sample <- sample(1:length(G4pos.seq),size=mysize)

bin_genome.sampled <- bin_genome[my.sample]
bin_genome.sampled %>% write_bed(str_c("data/bin_genome",my.seed,mysize,"sampled.bed",sep="_"))
#LOAD BIN
setwd("~/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/")
bin_genome.sampled <- read_bed(str_c("data/bin_genome",my.seed,mysize,"sampled.bed",sep="_"))
bin_genome.sampled_seq <- getSeq(BSgenome.Hsapiens.UCSC.hg19,bin_genome.sampled) 
bin_genome.sampled.num <- bin_genome.sampled_seq %>% DNAToNumerical

#G4 DATASET AND LOADING


dirG4 <- "/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/BED/"
myG4 <- list.files(dirG4,pattern="Ctrl_gkmSVM.bed")
ATAC_seq_data <- list(
  "GSE76688_HaCaT"=list("GSE76688_ATAC_entinostat_mean"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/GSE76688/HaCaT/ATACseq/PROCESSED/mapping/BIGWIG/ATAC_entinostat_mean.bw")),
  "GSE99205_HaCaT"=list("GSE76688_ATAC_entinostat_mean"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/GSE76688/HaCaT/ATACseq/PROCESSED/mapping/BIGWIG/ATAC_entinostat_mean.bw")),
  "GSE107690_K562"=list(
    "GSM4133303_YET96_ATAC_K652"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/GSE139190/ATACseq/GSM4133303_YET96_ATAC_K652.bw"),
    "GSM4133304_YET124_ATAC_K562"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/GSE139190/ATACseq/GSM4133304_YET124_ATAC_K562.bw"),
    "GSM2902637_K562_ATAC_no_lysis_buffer"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/GSE108513/GSM2902637_K562_ATAC_no_lysis_buffer.bw"),
    "GSM2902638_K562_DNase"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/GSE108513/GSM2902638_K562_DNase.bw")
  ),
  "breastCancer_qG4-ChIP-seq-of-breast-cancer-PDTX"=list(
    "DNAse-seq_MCF7"=list.files("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/DNAse-seq_MCF7",pattern = ".bigWig",full.names = T),
    "ATACseq-AWG_BRCA"=list.files("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/ATACseq-AWG_BRCA",pattern = ".bw",full.names = T)
  ),
  "GSE76688_HEKnp"=list(
    "GSE76688_HEKnp"=list.files("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/GSE76688/HEKnp/ATACseq/PROCESSED/mapping/BIGWIG",pattern = ".bw",full.names = T)
  ),
  "GSE133379_293T"=list(
    "DNAse-seq_HEK293T"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/DNAse-seq_HEK293T/ENCFF716SFD.bigWig")
  ),
  "GSE133379_A549"=list(
    "DNAse-seq_A549"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/ChIP-Atlas/SRX100904.bw")
  ),
  "GSE133379_HeLaS3"=list(
    "DNAse-seq_HeLaS3"=list("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/ChIP-Atlas/SRX100899.bw")
  ),
  "GSE133379_H1975"=list(
    "GSE142031_ATAC-seq"=list.files("/media/ElissarDisk/Elissar/Projects/DeepG4/Data/GEO/hg19/GSE142031/ATAC-seq",pattern = ".bw",full.names = T)
  )
)
for(oneG4 in myG4[8:18]){
  message(oneG4)
  if(str_detect(oneG4,"breastCancer_qG4-ChIP-seq-of-breast-cancer-PDTX_hg19")){
    ATAC_dataset <- ATAC_seq_data[["breastCancer_qG4-ChIP-seq-of-breast-cancer-PDTX"]]
  }else{
    GEO <- str_extract(oneG4,"GSE[0-9]+")
    cell_line <- str_extract(oneG4,"HaCaT|HEKnp|K562|breastCancer_qG4-ChIP-seq-of-breast-cancer-PDTX|293T|A549|H1975|HeLaS3")
    ATAC_dataset <- ATAC_seq_data[[str_c(GEO,cell_line,sep="_")]]
  }
  
  neg <- oneG4
  pos <- str_replace(neg,"_Ctrl_gkmSVM.bed",".bed")
  # #Process output dir
  GenName <- pos %>% str_remove(".bed")
  output_dir <- "/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/BinAUPR/"
  output_prefix <- str_c(GenName,my.seed,"bin_positions_sampled_for_auPR",sep="_")
  
  #Load data
  readBed <- . %>% read_tsv(col_names = F) %>% dplyr::select(1:3) %>% setNames(c("seqnames","start","end")) %>% as_granges()
  G4pos.bed <- str_c(dirG4,pos) %>% read_bed()
  if(unique(width(G4pos.bed)) != 201){
    G4pos.bed <- str_c(dirG4,pos) %>% readBed
  }
  
  

  ov <- findOverlaps(bin_genome.sampled,G4pos.bed,minoverlap = 50)
  
  labels <- rep(0,length(bin_genome.sampled))
  labels[queryHits(ov)] <- 1
  
  
  
  #Get ATAC-seq score for bed
  nb_cores <- ifelse(length(unlist(ATAC_dataset))>5,5,length(ATAC_dataset))
  G4all.atac <- ATAC_dataset %>% map(function(z){
    z %>% mclapply(function(x){
      xbw <- x %>% import.bw %>% NormBW(binbed)
      res <- xbw %>% getScoreBW(bin_genome.sampled)
      res[is.na(res)] <- 0
      return(res)
    },mc.cores = nb_cores) %>% purrr::reduce(`+`) / length(z)
  })
  
  dataOneHot <- list(
    "test"=list(
      "x"= bin_genome.sampled.num,
      "x_atac"= G4all.atac,
      "y"= labels
    ))
  saveRDS(dataOneHot,str_c(output_dir,output_prefix,"_OneHot_train_test.rds"))
  
}







